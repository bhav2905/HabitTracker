/*
================================================================================
  EXAMPREP PRO - DEPLOYMENT & SETUP GUIDE
================================================================================

Congratulations! You now have a fully functional Exam Preparation & Habit Tracker.

This guide will walk you through:
1. Running the application locally
2. Setting up MongoDB (optional)
3. Deploying to Vercel
4. Full-stack implementation with backend

================================================================================
  CURRENT IMPLEMENTATION (Demo Version)
================================================================================

The current version uses:
- Pure React (no build process needed)
- In-memory state management (data resets on page refresh)
- No backend server required
- Perfect for testing and demonstration

To run this version:
1. Simply open index.html in a web browser
2. OR use a local server:
   - Python: python -m http.server 8000
   - Node: npx http-server
   - VS Code: Use Live Server extension

================================================================================
  PART 1: LOCAL SETUP (Production-Ready Version)
================================================================================

For a production version with persistent data, you'll need to convert this
to a proper MERN stack application.

STEP 1: PROJECT STRUCTURE
-------------------------
Create this folder structure:

examprep-pro/
├── client/                    # Frontend
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/       # React components
│   │   ├── App.js           # Main app
│   │   ├── index.js         # Entry point
│   │   └── styles.css       # Styles
│   └── package.json
│
├── server/                   # Backend
│   ├── models/              # MongoDB schemas
│   │   ├── User.js
│   │   ├── Exam.js
│   │   ├── Habit.js
│   │   ├── Task.js
│   │   ├── Book.js
│   │   └── Movie.js
│   ├── routes/              # API routes
│   │   ├── auth.js
│   │   ├── exams.js
│   │   ├── habits.js
│   │   └── tasks.js
│   ├── server.js            # Express server
│   └── package.json
│
└── .env                      # Environment variables


STEP 2: BACKEND SETUP (Node.js + Express + MongoDB)
---------------------------------------------------

1. Initialize the backend:
   $ mkdir examprep-pro && cd examprep-pro
   $ mkdir server && cd server
   $ npm init -y

2. Install dependencies:
   $ npm install express mongoose cors dotenv bcryptjs jsonwebtoken
   $ npm install --save-dev nodemon

3. Create server/server.js:

   const express = require('express');
   const mongoose = require('mongoose');
   const cors = require('cors');
   require('dotenv').config();

   const app = express();

   // Middleware
   app.use(cors());
   app.use(express.json());

   // MongoDB Connection
   mongoose.connect(process.env.MONGODB_URI, {
     useNewUrlParser: true,
     useUnifiedTopology: true
   })
   .then(() => console.log('MongoDB Connected'))
   .catch(err => console.log('MongoDB Error:', err));

   // Routes
   app.use('/api/auth', require('./routes/auth'));
   app.use('/api/exams', require('./routes/exams'));
   app.use('/api/habits', require('./routes/habits'));
   app.use('/api/tasks', require('./routes/tasks'));
   app.use('/api/books', require('./routes/books'));
   app.use('/api/movies', require('./routes/movies'));

   const PORT = process.env.PORT || 5000;
   app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

4. Create .env file in root:
   
   MONGODB_URI=mongodb://localhost:27017/examprep
   JWT_SECRET=your_secret_key_here_change_this_in_production
   PORT=5000

5. Create package.json scripts:
   
   "scripts": {
     "start": "node server.js",
     "dev": "nodemon server.js"
   }


STEP 3: MONGODB SETUP (LOCAL)
------------------------------

Option A: Local MongoDB Installation
1. Download MongoDB Community Server from mongodb.com
2. Install and run MongoDB:
   - Windows: Run as service or mongod.exe
   - Mac: brew services start mongodb-community
   - Linux: sudo systemctl start mongod
3. Verify: mongo --version

Option B: MongoDB Atlas (Cloud - Recommended)
1. Go to mongodb.com/cloud/atlas
2. Create free account
3. Create a cluster (free tier available)
4. Click "Connect" > "Connect your application"
5. Copy connection string
6. Update .env:
   MONGODB_URI=mongodb+srv://<username>:<password>@cluster.mongodb.net/examprep


STEP 4: FRONTEND SETUP (React with Create React App)
-----------------------------------------------------

1. Create React app:
   $ cd .. (back to root)
   $ npx create-react-app client
   $ cd client

2. Install dependencies:
   $ npm install axios react-router-dom

3. Copy the current app code into src/:
   - Create components folder
   - Split the large app.js into separate components
   - Update to use axios for API calls instead of in-memory state

4. Configure proxy in client/package.json:
   "proxy": "http://localhost:5000"

5. Example API integration (in a React component):

   import axios from 'axios';

   // Fetch exams
   const fetchExams = async () => {
     try {
       const response = await axios.get('/api/exams');
       setExams(response.data);
     } catch (error) {
       console.error('Error fetching exams:', error);
     }
   };

   // Add exam
   const addExam = async (examData) => {
     try {
       const response = await axios.post('/api/exams', examData);
       setExams([...exams, response.data]);
     } catch (error) {
       console.error('Error adding exam:', error);
     }
   };


STEP 5: RUNNING LOCALLY
-----------------------

1. Start MongoDB (if using local):
   $ mongod

2. Start backend server:
   $ cd server
   $ npm run dev
   
   You should see:
   - "Server running on port 5000"
   - "MongoDB Connected"

3. Start frontend (in new terminal):
   $ cd client
   $ npm start
   
   React app opens at http://localhost:3000

4. Test the application:
   - Register a new user
   - Login
   - Add exams, habits, tasks
   - Data persists in MongoDB


================================================================================
  PART 2: DEPLOYING TO VERCEL
================================================================================

Vercel is perfect for deploying React applications. For full-stack apps,
you have two deployment strategies:

STRATEGY A: Frontend Only (Current Demo Version)
-------------------------------------------------

1. Install Vercel CLI:
   $ npm install -g vercel

2. Login to Vercel:
   $ vercel login

3. Deploy:
   $ vercel
   
   Follow prompts:
   - Set up and deploy: Y
   - Which scope: Your account
   - Link to existing project: N
   - Project name: examprep-pro
   - Directory: ./ (or where index.html is)
   - Build command: (leave empty)
   - Output directory: (leave empty)

4. Your app is now live at: https://examprep-pro.vercel.app

NOTE: This version won't persist data (refreshing resets everything)


STRATEGY B: Full-Stack Deployment
----------------------------------

For a full production app, split deployment:

BACKEND (Deploy to Heroku, Railway, or Render):

1. Using Heroku:
   $ heroku login
   $ cd server
   $ git init
   $ heroku create examprep-backend
   
2. Set environment variables:
   $ heroku config:set MONGODB_URI=your_mongodb_atlas_uri
   $ heroku config:set JWT_SECRET=your_secret
   
3. Deploy:
   $ git add .
   $ git commit -m "Deploy backend"
   $ git push heroku main
   
4. Your API is at: https://examprep-backend.herokuapp.com

FRONTEND (Deploy to Vercel):

1. Update API calls in React to use production backend URL:
   
   // In src/config.js
   export const API_URL = process.env.REACT_APP_API_URL || 
                          'https://examprep-backend.herokuapp.com';
   
   // Use in components
   import { API_URL } from './config';
   axios.get(`${API_URL}/api/exams`);

2. Build the React app:
   $ cd client
   $ npm run build

3. Deploy to Vercel:
   $ vercel --prod

4. Set environment variable in Vercel dashboard:
   - Go to vercel.com > Your Project > Settings > Environment Variables
   - Add: REACT_APP_API_URL = https://examprep-backend.herokuapp.com

5. Redeploy to apply changes:
   $ vercel --prod


================================================================================
  PART 3: DATABASE MODELS (MongoDB Schemas)
================================================================================

Here are the MongoDB schemas you'll need:

// server/models/User.js
const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  isAdmin: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('User', UserSchema);


// server/models/Exam.js
const mongoose = require('mongoose');

const ExamSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true },
  date: { type: String, required: true },
  time: String,
  totalTopics: { type: Number, default: 0 },
  description: String,
  progress: { type: Number, default: 0 },
  completed: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Exam', ExamSchema);


// server/models/Subject.js
const mongoose = require('mongoose');

const SubjectSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  examId: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
  name: { type: String, required: true },
  progress: { type: Number, default: 0 },
  completed: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Subject', SubjectSchema);


// Similar models for Habit, Task, Book, Movie...


================================================================================
  PART 4: API ROUTES EXAMPLES
================================================================================

// server/routes/auth.js
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, isAdmin, adminKey } = req.body;
    
    // Check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }
    
    // Validate admin key if registering as admin
    if (isAdmin && adminKey !== 'admin123') {
      return res.status(400).json({ message: 'Invalid admin key' });
    }
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Create user
    const user = new User({
      name,
      email,
      password: hashedPassword,
      isAdmin: isAdmin || false
    });
    
    await user.save();
    
    // Create token
    const token = jwt.sign(
      { userId: user._id, isAdmin: user.isAdmin },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    res.status(201).json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        isAdmin: user.isAdmin
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    const token = jwt.sign(
      { userId: user._id, isAdmin: user.isAdmin },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    res.json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        isAdmin: user.isAdmin
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;


// server/routes/exams.js
const router = require('express').Router();
const Exam = require('../models/Exam');
const auth = require('../middleware/auth'); // JWT verification middleware

// Get all exams for user
router.get('/', auth, async (req, res) => {
  try {
    const exams = await Exam.find({ userId: req.user.userId });
    res.json(exams);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Create exam
router.post('/', auth, async (req, res) => {
  try {
    const exam = new Exam({
      ...req.body,
      userId: req.user.userId
    });
    await exam.save();
    res.status(201).json(exam);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Update exam
router.put('/:id', auth, async (req, res) => {
  try {
    const exam = await Exam.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.userId },
      req.body,
      { new: true }
    );
    if (!exam) {
      return res.status(404).json({ message: 'Exam not found' });
    }
    res.json(exam);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Delete exam
router.delete('/:id', auth, async (req, res) => {
  try {
    const exam = await Exam.findOneAndDelete({
      _id: req.params.id,
      userId: req.user.userId
    });
    if (!exam) {
      return res.status(404).json({ message: 'Exam not found' });
    }
    res.json({ message: 'Exam deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;


================================================================================
  PART 5: ENVIRONMENT VARIABLES CHECKLIST
================================================================================

Local Development (.env file):
- MONGODB_URI=mongodb://localhost:27017/examprep
- JWT_SECRET=your_secret_key_minimum_32_characters
- PORT=5000
- NODE_ENV=development

Production (Set in Heroku/Railway/Render):
- MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/examprep
- JWT_SECRET=different_secret_for_production
- PORT=5000
- NODE_ENV=production

Frontend (Set in Vercel):
- REACT_APP_API_URL=https://your-backend.herokuapp.com


================================================================================
  PART 6: TESTING CHECKLIST
================================================================================

Local Testing:
☑ MongoDB running
☑ Backend server starts without errors
☑ Frontend connects to backend
☑ User registration works
☑ User login works
☑ All CRUD operations work (Create, Read, Update, Delete)
☑ Admin panel accessible for admin users
☑ Data persists after page refresh

 Production Testing:
☑ Backend deployed and accessible
☑ Frontend deployed and accessible
☑ Frontend can communicate with backend (CORS configured)
☑ Environment variables set correctly
☑ Database connection works
☑ SSL/HTTPS enabled
☑ Authentication works in production


================================================================================
  PART 7: TROUBLESHOOTING
================================================================================

Common Issues:

1. "Cannot connect to MongoDB"
   - Check MongoDB is running: $ mongod --version
   - Verify connection string in .env
   - Check network access in MongoDB Atlas (allow all IPs for testing)

2. "CORS Error" when frontend calls backend
   - Install cors: $ npm install cors
   - Add to server.js: app.use(cors());
   - Or configure specific origins:
     app.use(cors({ origin: 'https://your-frontend.vercel.app' }));

3. "JWT Error" / Authentication fails
   - Check JWT_SECRET is set in .env
   - Verify token is being sent in headers
   - Check token expiration

4. "Vercel deployment fails"
   - Check build logs in Vercel dashboard
   - Ensure all dependencies in package.json
   - Verify build command is correct

5. Data doesn't persist
   - Check MongoDB connection
   - Verify API calls are using axios (not in-memory state)
   - Check browser console for API errors


================================================================================
  PART 8: ADDITIONAL FEATURES TO ADD
================================================================================

Enhancements you can implement:

1. Email Notifications
   - Exam reminders
   - Streak notifications
   - Install nodemailer

2. File Uploads
   - Study materials
   - Notes attachments
   - Install multer

3. Advanced Analytics
   - Study time tracking
   - Progress charts
   - Install Chart.js (already included)

4. Social Features
   - Share progress
   - Study groups
   - Leaderboards

5. Mobile App
   - React Native version
   - Progressive Web App (PWA)

6. AI Integration
   - Study recommendations
   - Smart scheduling
   - OpenAI API


================================================================================
  PART 9: SECURITY BEST PRACTICES
================================================================================

1. Password Security
   - Always hash passwords (bcryptjs)
   - Never store plain text passwords
   - Implement password strength validation

2. JWT Security
   - Use strong secret keys (32+ characters)
   - Set reasonable expiration times
   - Implement token refresh mechanism

3. Input Validation
   - Validate all user inputs
   - Sanitize data before database operations
   - Use express-validator

4. Rate Limiting
   - Prevent brute force attacks
   - Install express-rate-limit

5. HTTPS
   - Always use HTTPS in production
   - Vercel provides this automatically

6. Environment Variables
   - Never commit .env files
   - Add .env to .gitignore
   - Use different secrets for dev/prod


================================================================================
  PART 10: PERFORMANCE OPTIMIZATION
================================================================================

1. Frontend Optimization
   - Code splitting
   - Lazy loading components
   - Optimize images
   - Implement caching

2. Backend Optimization
   - Database indexing
   - Query optimization
   - Implement Redis caching
   - Use compression middleware

3. MongoDB Optimization
   - Create indexes on frequently queried fields
   - Use aggregation pipelines
   - Implement pagination

4. Network Optimization
   - Minimize API calls
   - Batch requests
   - Implement debouncing/throttling


================================================================================
  CONTACT & SUPPORT
================================================================================

If you encounter any issues or need help:

1. Check the documentation above
2. Review error messages carefully
3. Check browser console for frontend errors
4. Check server logs for backend errors
5. Verify all environment variables are set

Remember:
- Start simple (demo version works out of the box)
- Add complexity gradually (add backend when needed)
- Test thoroughly at each step
- Keep backups of working code

Good luck with your ExamPrep Pro application!

Made with ❤️ by Bhav

================================================================================
*/

// This file is for documentation purposes only.
// No executable code here - just comprehensive deployment instructions!

console.log('ExamPrep Pro - Deployment Guide Loaded');
console.log('Check the comments in this file for complete deployment instructions')