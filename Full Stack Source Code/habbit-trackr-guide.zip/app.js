const { useState, useEffect, useRef } = React;

// ============= INITIAL DATA =============
const ADMIN_SECRET_KEY = 'admin123';

const initialUsers = [
  {
    id: 1,
    email: 'user@example.com',
    password: 'user123',
    name: 'Demo User',
    isAdmin: false
  },
  {
    id: 2,
    email: 'admin@example.com',
    password: 'admin123',
    name: 'Admin User',
    isAdmin: true
  }
];

// ============= MAIN APP COMPONENT =============
function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [users, setUsers] = useState(initialUsers);
  const [darkMode, setDarkMode] = useState(false);
  const [activeView, setActiveView] = useState('dashboard');

  // Data States
  const [exams, setExams] = useState([]);
  const [habits, setHabits] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [books, setBooks] = useState([]);
  const [movies, setMovies] = useState([]);
  const [subjects, setSubjects] = useState([]);

  useEffect(() => {
    if (darkMode) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
  }, [darkMode]);

  const logout = () => {
    setCurrentUser(null);
    setActiveView('dashboard');
  };

  if (!currentUser) {
    return <AuthScreen users={users} setUsers={setUsers} setCurrentUser={setCurrentUser} />;
  }

  return (
    <>
      <div className="dashboard-container">
        <Sidebar 
          activeView={activeView} 
          setActiveView={setActiveView} 
          currentUser={currentUser}
          logout={logout}
        />
        <div className="main-content">
          {activeView === 'dashboard' && (
            <Dashboard 
              exams={exams}
              habits={habits}
              tasks={tasks}
              books={books}
              movies={movies}
              subjects={subjects}
            />
          )}
          {activeView === 'exams' && (
            <ExamsView 
              exams={exams}
              setExams={setExams}
              subjects={subjects}
              setSubjects={setSubjects}
            />
          )}
          {activeView === 'habits' && (
            <HabitsView habits={habits} setHabits={setHabits} />
          )}
          {activeView === 'tasks' && (
            <TasksView tasks={tasks} setTasks={setTasks} />
          )}
          {activeView === 'books' && (
            <BooksView books={books} setBooks={setBooks} />
          )}
          {activeView === 'movies' && (
            <MoviesView movies={movies} setMovies={setMovies} />
          )}
          {activeView === 'calendar' && (
            <CalendarView exams={exams} tasks={tasks} />
          )}
          {activeView === 'kanban' && (
            <KanbanView tasks={tasks} setTasks={setTasks} subjects={subjects} setSubjects={setSubjects} />
          )}
          {activeView === 'admin' && currentUser.isAdmin && (
            <AdminPanel 
              users={users}
              setUsers={setUsers}
              exams={exams}
              setExams={setExams}
              habits={habits}
              setHabits={setHabits}
              tasks={tasks}
              setTasks={setTasks}
              books={books}
              setBooks={setBooks}
              movies={movies}
              setMovies={setMovies}
              subjects={subjects}
              setSubjects={setSubjects}
            />
          )}
          <Footer />
        </div>
      </div>
      <button 
        className="theme-toggle" 
        onClick={() => setDarkMode(!darkMode)}
        aria-label="Toggle theme"
      >
        <i className={`fas fa-${darkMode ? 'sun' : 'moon'}`}></i>
      </button>
    </>
  );
}

// ============= AUTH SCREEN =============
function AuthScreen({ users, setUsers, setCurrentUser }) {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    adminKey: '',
    isAdminSignup: false
  });
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    if (isLogin) {
      const user = users.find(u => u.email === formData.email && u.password === formData.password);
      if (user) {
        setCurrentUser(user);
      } else {
        setError('Invalid credentials');
      }
    } else {
      if (users.find(u => u.email === formData.email)) {
        setError('Email already exists');
        return;
      }

      if (formData.isAdminSignup && formData.adminKey !== ADMIN_SECRET_KEY) {
        setError('Invalid admin key');
        return;
      }

      const newUser = {
        id: users.length + 1,
        email: formData.email,
        password: formData.password,
        name: formData.name,
        isAdmin: formData.isAdminSignup
      };
      setUsers([...users, newUser]);
      setCurrentUser(newUser);
    }
  };

  return (
    <div className="parallax-hero">
      <div className="auth-container">
        <div className="text-center mb-4">
          <h1 className="mb-2" style={{ color: 'var(--primary-color)', fontSize: '2rem', fontWeight: '700' }}>
            <i className="fas fa-graduation-cap me-2"></i>
            ExamPrep Pro
          </h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
            Your Ultimate Exam Preparation &amp; Habit Tracker
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          {!isLogin && (
            <div className="mb-3">
              <label className="form-label" style={{ fontWeight: '600', fontSize: '0.9rem' }}>Full Name</label>
              <input
                type="text"
                className="form-control-custom"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                required={!isLogin}
                placeholder="Enter your name"
              />
            </div>
          )}

          <div className="mb-3">
            <label className="form-label" style={{ fontWeight: '600', fontSize: '0.9rem' }}>Email</label>
            <input
              type="email"
              className="form-control-custom"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              required
              placeholder="Enter your email"
            />
          </div>

          <div className="mb-3">
            <label className="form-label" style={{ fontWeight: '600', fontSize: '0.9rem' }}>Password</label>
            <input
              type="password"
              className="form-control-custom"
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              required
              placeholder="Enter your password"
            />
          </div>

          {!isLogin && (
            <>
              <div className="mb-3 form-check">
                <input
                  type="checkbox"
                  className="form-check-input checkbox-custom"
                  id="adminCheck"
                  checked={formData.isAdminSignup}
                  onChange={(e) => setFormData({...formData, isAdminSignup: e.target.checked})}
                />
                <label className="form-check-label" htmlFor="adminCheck" style={{ fontSize: '0.9rem' }}>
                  Register as Admin
                </label>
              </div>

              {formData.isAdminSignup && (
                <div className="mb-3">
                  <label className="form-label" style={{ fontWeight: '600', fontSize: '0.9rem' }}>Admin Secret Key</label>
                  <input
                    type="password"
                    className="form-control-custom"
                    value={formData.adminKey}
                    onChange={(e) => setFormData({...formData, adminKey: e.target.value})}
                    required={formData.isAdminSignup}
                    placeholder="Enter admin secret key"
                  />
                </div>
              )}
            </>
          )}

          {error && (
            <div className="alert alert-danger" role="alert" style={{ borderRadius: '12px', fontSize: '0.9rem' }}>
              {error}
            </div>
          )}

          <button type="submit" className="btn-primary-custom btn-custom w-100 mb-3">
            <i className={`fas fa-${isLogin ? 'sign-in-alt' : 'user-plus'} me-2`}></i>
            {isLogin ? 'Login' : 'Sign Up'}
          </button>

          <div className="text-center">
            <button
              type="button"
              className="btn btn-link"
              onClick={() => {
                setIsLogin(!isLogin);
                setError('');
                setFormData({ email: '', password: '', name: '', adminKey: '', isAdminSignup: false });
              }}
              style={{ color: 'var(--primary-color)', textDecoration: 'none', fontSize: '0.9rem' }}
            >
              {isLogin ? "Don't have an account? Sign Up" : 'Already have an account? Login'}
            </button>
          </div>
        </form>

        <div className="mt-4 p-3" style={{ background: 'rgba(99, 102, 241, 0.1)', borderRadius: '12px', fontSize: '0.85rem' }}>
          <p className="mb-2" style={{ fontWeight: '600' }}>Demo Credentials:</p>
          <p className="mb-1">User: user@example.com / user123</p>
          <p className="mb-0">Admin: admin@example.com / admin123</p>
        </div>
      </div>
    </div>
  );
}

// ============= SIDEBAR =============
function Sidebar({ activeView, setActiveView, currentUser, logout }) {
  const menuItems = [
    { id: 'dashboard', icon: 'tachometer-alt', label: 'Dashboard' },
    { id: 'exams', icon: 'book-open', label: 'Exams & Syllabus' },
    { id: 'habits', icon: 'check-circle', label: 'Habits' },
    { id: 'tasks', icon: 'tasks', label: 'Daily Tasks' },
    { id: 'books', icon: 'book', label: 'Books' },
    { id: 'movies', icon: 'film', label: 'Movies' },
    { id: 'calendar', icon: 'calendar-alt', label: 'Calendar' },
    { id: 'kanban', icon: 'columns', label: 'Kanban Board' },
  ];

  if (currentUser.isAdmin) {
    menuItems.push({ id: 'admin', icon: 'user-shield', label: 'Admin Panel' });
  }

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <h3 style={{ color: 'var(--primary-color)', fontWeight: '700', marginBottom: '0.5rem' }}>
          <i className="fas fa-graduation-cap me-2"></i>
          ExamPrep Pro
        </h3>
        <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: 0 }}>
          Welcome, {currentUser.name}
        </p>
      </div>
      <nav className="sidebar-nav">
        {menuItems.map(item => (
          <div
            key={item.id}
            className={`nav-item ${activeView === item.id ? 'active' : ''}`}
            onClick={() => setActiveView(item.id)}
          >
            <i className={`fas fa-${item.icon}`}></i>
            <span>{item.label}</span>
          </div>
        ))}
        <div className="nav-item" onClick={logout} style={{ marginTop: '2rem', color: 'var(--danger-color)' }}>
          <i className="fas fa-sign-out-alt"></i>
          <span>Logout</span>
        </div>
      </nav>
    </div>
  );
}

// ============= DASHBOARD =============
function Dashboard({ exams, habits, tasks, books, movies, subjects }) {
  const completedExams = exams.filter(e => e.completed).length;
  const activeHabits = habits.filter(h => !h.completed).length;
  const completedTasks = tasks.filter(t => t.completed).length;
  const completedBooks = books.filter(b => b.completed).length;

  const stats = [
    { icon: 'book-open', label: 'Active Exams', value: exams.length - completedExams, color: 'primary' },
    { icon: 'check-circle', label: 'Active Habits', value: activeHabits, color: 'success' },
    { icon: 'tasks', label: 'Completed Tasks', value: completedTasks, color: 'warning' },
    { icon: 'book', label: 'Books Read', value: completedBooks, color: 'danger' },
  ];

  return (
    <div>
      <div className="mb-4">
        <h2 style={{ fontWeight: '700', marginBottom: '0.5rem' }}>Dashboard</h2>
        <p style={{ color: 'var(--text-secondary)' }}>Overview of your progress and activities</p>
      </div>

      <div className="row g-4 mb-4">
        {stats.map((stat, index) => (
          <div className="col-md-6 col-lg-3" key={index}>
            <div className="stat-card">
              <div className={`stat-card-icon icon-${stat.color}`}>
                <i className={`fas fa-${stat.icon}`}></i>
              </div>
              <h3 style={{ fontSize: '2rem', fontWeight: '700', marginBottom: '0.25rem' }}>{stat.value}</h3>
              <p style={{ color: 'var(--text-secondary)', marginBottom: 0 }}>{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="row g-4">
        <div className="col-lg-6">
          <div className="stat-card">
            <h4 className="mb-3" style={{ fontWeight: '600' }}>
              <i className="fas fa-book-open me-2" style={{ color: 'var(--primary-color)' }}></i>
              Upcoming Exams
            </h4>
            {exams.filter(e => !e.completed).slice(0, 3).map(exam => (
              <div key={exam.id} className="mb-3 p-3" style={{ background: 'var(--light-bg)', borderRadius: '12px', borderLeft: '4px solid var(--primary-color)' }}>
                <div className="d-flex justify-content-between align-items-start mb-2">
                  <h5 style={{ fontWeight: '600', marginBottom: '0.25rem' }}>{exam.name}</h5>
                  <span className="badge-custom badge-primary">{exam.date}</span>
                </div>
                <div className="progress-custom mb-2">
                  <div className="progress-bar-custom" style={{ width: `${exam.progress}%` }}></div>
                </div>
                <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: 0 }}>
                  {exam.progress}% Complete • {calculateDaysRemaining(exam.date)} days left
                </p>
              </div>
            ))}
            {exams.filter(e => !e.completed).length === 0 && (
              <p style={{ color: 'var(--text-secondary)', textAlign: 'center', padding: '2rem' }}>
                No upcoming exams. Add one to get started!
              </p>
            )}
          </div>
        </div>

        <div className="col-lg-6">
          <div className="stat-card">
            <h4 className="mb-3" style={{ fontWeight: '600' }}>
              <i className="fas fa-fire me-2" style={{ color: 'var(--danger-color)' }}></i>
              Habit Streaks
            </h4>
            {habits.slice(0, 5).map(habit => (
              <div key={habit.id} className="mb-3 p-3" style={{ background: 'var(--light-bg)', borderRadius: '12px' }}>
                <div className="d-flex justify-content-between align-items-center">
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '0.25rem' }}>{habit.name}</h6>
                    <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: 0 }}>
                      {habit.frequency}
                    </p>
                  </div>
                  <div className="streak-display">
                    <i className="fas fa-fire"></i>
                    {habit.streak} days
                  </div>
                </div>
              </div>
            ))}
            {habits.length === 0 && (
              <p style={{ color: 'var(--text-secondary)', textAlign: 'center', padding: '2rem' }}>
                No habits tracked yet. Start building your routine!
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============= EXAMS VIEW =============
function ExamsView({ exams, setExams, subjects, setSubjects }) {
  const [showModal, setShowModal] = useState(false);
  const [editingExam, setEditingExam] = useState(null);
  const [showSubjectModal, setShowSubjectModal] = useState(false);
  const [currentExamId, setCurrentExamId] = useState(null);

  const [formData, setFormData] = useState({
    name: '',
    date: '',
    time: '',
    totalTopics: 0,
    description: ''
  });

  const openModal = (exam = null) => {
    if (exam) {
      setEditingExam(exam);
      setFormData({
        name: exam.name,
        date: exam.date,
        time: exam.time || '',
        totalTopics: exam.totalTopics,
        description: exam.description || ''
      });
    } else {
      setEditingExam(null);
      setFormData({ name: '', date: '', time: '', totalTopics: 0, description: '' });
    }
    setShowModal(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingExam) {
      setExams(exams.map(ex => 
        ex.id === editingExam.id 
          ? { ...ex, ...formData, progress: calculateProgress(editingExam.id) }
          : ex
      ));
    } else {
      const newExam = {
        id: Date.now(),
        ...formData,
        completed: false,
        progress: 0
      };
      setExams([...exams, newExam]);
    }
    setShowModal(false);
  };

  const deleteExam = (id) => {
    if (confirm('Are you sure you want to delete this exam?')) {
      setExams(exams.filter(ex => ex.id !== id));
      setSubjects(subjects.filter(s => s.examId !== id));
    }
  };

  const toggleComplete = (id) => {
    setExams(exams.map(ex => 
      ex.id === id ? { ...ex, completed: !ex.completed } : ex
    ));
  };

  const calculateProgress = (examId) => {
    const examSubjects = subjects.filter(s => s.examId === examId);
    if (examSubjects.length === 0) return 0;
    const totalProgress = examSubjects.reduce((sum, s) => sum + s.progress, 0);
    return Math.round(totalProgress / examSubjects.length);
  };

  const openSubjectModal = (examId) => {
    setCurrentExamId(examId);
    setShowSubjectModal(true);
  };

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 style={{ fontWeight: '700', marginBottom: '0.5rem' }}>Exams &amp; Syllabus</h2>
          <p style={{ color: 'var(--text-secondary)' }}>Manage your exams and track syllabus progress</p>
        </div>
        <button className="btn-primary-custom btn-custom" onClick={() => openModal()}>
          <i className="fas fa-plus me-2"></i>
          Add Exam
        </button>
      </div>

      <div className="row g-4">
        {exams.map(exam => {
          const examSubjects = subjects.filter(s => s.examId === exam.id);
          const progress = calculateProgress(exam.id);
          const daysLeft = calculateDaysRemaining(exam.date);
          
          return (
            <div className="col-lg-6" key={exam.id}>
              <div className="stat-card">
                <div className="d-flex justify-content-between align-items-start mb-3">
                  <div>
                    <h4 style={{ fontWeight: '700', marginBottom: '0.5rem' }}>{exam.name}</h4>
                    <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: 0 }}>
                      {exam.description}
                    </p>
                  </div>
                  <div className="d-flex gap-2">
                    <button 
                      className="btn-secondary-custom btn-custom btn-sm"
                      onClick={() => openModal(exam)}
                    >
                      <i className="fas fa-edit"></i>
                    </button>
                    <button 
                      className="btn-danger-custom btn-custom btn-sm"
                      onClick={() => deleteExam(exam.id)}
                    >
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </div>

                <div className="mb-3">
                  <div className="d-flex justify-content-between mb-2">
                    <span style={{ fontSize: '0.9rem', fontWeight: '600' }}>Overall Progress</span>
                    <span style={{ fontSize: '0.9rem', fontWeight: '600', color: 'var(--primary-color)' }}>
                      {progress}%
                    </span>
                  </div>
                  <div className="progress-custom">
                    <div className="progress-bar-custom" style={{ width: `${progress}%` }}></div>
                  </div>
                </div>

                <div className="d-flex justify-content-between mb-3">
                  <span className="badge-custom badge-primary">
                    <i className="fas fa-calendar me-2"></i>
                    {exam.date} {exam.time && `at ${exam.time}`}
                  </span>
                  <span className={`badge-custom badge-${daysLeft <= 7 ? 'danger' : 'warning'}`}>
                    <i className="fas fa-clock me-2"></i>
                    {daysLeft} days left
                  </span>
                </div>

                <div className="mb-3">
                  <button 
                    className="btn-primary-custom btn-custom btn-sm w-100 mb-2"
                    onClick={() => openSubjectModal(exam.id)}
                  >
                    <i className="fas fa-plus me-2"></i>
                    Add Subject/Topic
                  </button>
                  
                  {examSubjects.length > 0 && (
                    <div className="mt-3">
                      <h6 style={{ fontWeight: '600', marginBottom: '0.75rem' }}>Subjects:</h6>
                      {examSubjects.map(subject => (
                        <SubjectCard 
                          key={subject.id} 
                          subject={subject} 
                          subjects={subjects}
                          setSubjects={setSubjects}
                        />
                      ))}
                    </div>
                  )}
                </div>

                <div className="form-check">
                  <input
                    type="checkbox"
                    className="form-check-input checkbox-custom"
                    id={`exam-${exam.id}`}
                    checked={exam.completed}
                    onChange={() => toggleComplete(exam.id)}
                  />
                  <label className="form-check-label" htmlFor={`exam-${exam.id}`}>
                    Mark as Completed
                  </label>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {exams.length === 0 && (
        <div className="text-center py-5">
          <i className="fas fa-book-open" style={{ fontSize: '4rem', color: 'var(--primary-color)', opacity: 0.3 }}></i>
          <p style={{ marginTop: '1rem', color: 'var(--text-secondary)' }}>No exams added yet. Click "Add Exam" to get started!</p>
        </div>
      )}

      {showModal && (
        <div className="modal-custom" onClick={() => setShowModal(false)}>
          <div className="modal-content-custom" onClick={(e) => e.stopPropagation()}>
            <h3 className="mb-4" style={{ fontWeight: '700' }}>
              {editingExam ? 'Edit Exam' : 'Add New Exam'}
            </h3>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Exam Name</label>
                <input
                  type="text"
                  className="form-control-custom"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                  placeholder="e.g., Mathematics Final"
                />
              </div>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label" style={{ fontWeight: '600' }}>Date</label>
                  <input
                    type="date"
                    className="form-control-custom"
                    value={formData.date}
                    onChange={(e) => setFormData({...formData, date: e.target.value})}
                    required
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label" style={{ fontWeight: '600' }}>Time (Optional)</label>
                  <input
                    type="time"
                    className="form-control-custom"
                    value={formData.time}
                    onChange={(e) => setFormData({...formData, time: e.target.value})}
                  />
                </div>
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Total Topics</label>
                <input
                  type="number"
                  className="form-control-custom"
                  value={formData.totalTopics}
                  onChange={(e) => setFormData({...formData, totalTopics: parseInt(e.target.value) || 0})}
                  min="0"
                />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Description</label>
                <textarea
                  className="form-control-custom"
                  rows="3"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Add any notes or details about this exam"
                ></textarea>
              </div>
              <div className="d-flex gap-2">
                <button type="submit" className="btn-primary-custom btn-custom flex-grow-1">
                  <i className="fas fa-save me-2"></i>
                  {editingExam ? 'Update' : 'Add'} Exam
                </button>
                <button 
                  type="button" 
                  className="btn-secondary-custom btn-custom"
                  onClick={() => setShowModal(false)}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showSubjectModal && (
        <SubjectModal 
          examId={currentExamId}
          subjects={subjects}
          setSubjects={setSubjects}
          onClose={() => setShowSubjectModal(false)}
        />
      )}
    </div>
  );
}

// Subject Card Component
function SubjectCard({ subject, subjects, setSubjects }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({ ...subject });

  const handleUpdate = () => {
    setSubjects(subjects.map(s => s.id === subject.id ? editData : s));
    setIsEditing(false);
  };

  const handleDelete = () => {
    if (confirm('Delete this subject?')) {
      setSubjects(subjects.filter(s => s.id !== subject.id));
    }
  };

  const toggleComplete = () => {
    setSubjects(subjects.map(s => 
      s.id === subject.id ? { ...s, completed: !s.completed } : s
    ));
  };

  if (isEditing) {
    return (
      <div className="mb-2 p-3" style={{ background: 'var(--light-bg)', borderRadius: '12px' }}>
        <input
          type="text"
          className="form-control-custom mb-2"
          value={editData.name}
          onChange={(e) => setEditData({...editData, name: e.target.value})}
          placeholder="Subject name"
        />
        <input
          type="number"
          className="form-control-custom mb-2"
          value={editData.progress}
          onChange={(e) => setEditData({...editData, progress: Math.min(100, Math.max(0, parseInt(e.target.value) || 0))})}
          min="0"
          max="100"
          placeholder="Progress %"
        />
        <div className="d-flex gap-2">
          <button className="btn-success-custom btn-custom btn-sm" onClick={handleUpdate}>
            <i className="fas fa-check"></i> Save
          </button>
          <button className="btn-secondary-custom btn-custom btn-sm" onClick={() => setIsEditing(false)}>
            Cancel
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-2 p-3" style={{ 
      background: 'var(--light-bg)', 
      borderRadius: '12px',
      textDecoration: subject.completed ? 'line-through' : 'none',
      opacity: subject.completed ? 0.6 : 1
    }}>
      <div className="d-flex justify-content-between align-items-center mb-2">
        <div className="d-flex align-items-center gap-2">
          <input
            type="checkbox"
            className="checkbox-custom"
            checked={subject.completed}
            onChange={toggleComplete}
          />
          <span style={{ fontWeight: '600' }}>{subject.name}</span>
        </div>
        <div className="d-flex gap-2">
          <button className="btn-secondary-custom btn-custom btn-sm" onClick={() => setIsEditing(true)}>
            <i className="fas fa-edit"></i>
          </button>
          <button className="btn-danger-custom btn-custom btn-sm" onClick={handleDelete}>
            <i className="fas fa-trash"></i>
          </button>
        </div>
      </div>
      <div className="d-flex justify-content-between align-items-center mb-2">
        <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>Progress</span>
        <span style={{ fontSize: '0.875rem', fontWeight: '600', color: 'var(--primary-color)' }}>
          {subject.progress}%
        </span>
      </div>
      <div className="progress-custom">
        <div className="progress-bar-custom" style={{ width: `${subject.progress}%` }}></div>
      </div>
    </div>
  );
}

// Subject Modal
function SubjectModal({ examId, subjects, setSubjects, onClose }) {
  const [formData, setFormData] = useState({ name: '', progress: 0 });

  const handleSubmit = (e) => {
    e.preventDefault();
    const newSubject = {
      id: Date.now(),
      examId: examId,
      name: formData.name,
      progress: formData.progress,
      completed: false
    };
    setSubjects([...subjects, newSubject]);
    onClose();
  };

  return (
    <div className="modal-custom" onClick={onClose}>
      <div className="modal-content-custom" onClick={(e) => e.stopPropagation()}>
        <h3 className="mb-4" style={{ fontWeight: '700' }}>Add Subject/Topic</h3>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label" style={{ fontWeight: '600' }}>Subject/Topic Name</label>
            <input
              type="text"
              className="form-control-custom"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              required
              placeholder="e.g., Calculus Chapter 5"
            />
          </div>
          <div className="mb-3">
            <label className="form-label" style={{ fontWeight: '600' }}>Progress (%)</label>
            <input
              type="number"
              className="form-control-custom"
              value={formData.progress}
              onChange={(e) => setFormData({...formData, progress: Math.min(100, Math.max(0, parseInt(e.target.value) || 0))})}
              min="0"
              max="100"
            />
          </div>
          <div className="d-flex gap-2">
            <button type="submit" className="btn-primary-custom btn-custom flex-grow-1">
              <i className="fas fa-plus me-2"></i>
              Add Subject
            </button>
            <button type="button" className="btn-secondary-custom btn-custom" onClick={onClose}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============= HABITS VIEW =============
function HabitsView({ habits, setHabits }) {
  const [showModal, setShowModal] = useState(false);
  const [editingHabit, setEditingHabit] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    frequency: 'Daily',
    streak: 0,
    description: ''
  });

  const openModal = (habit = null) => {
    if (habit) {
      setEditingHabit(habit);
      setFormData({ ...habit });
    } else {
      setEditingHabit(null);
      setFormData({ name: '', frequency: 'Daily', streak: 0, description: '' });
    }
    setShowModal(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingHabit) {
      setHabits(habits.map(h => h.id === editingHabit.id ? { ...h, ...formData } : h));
    } else {
      setHabits([...habits, { id: Date.now(), ...formData, completed: false }]);
    }
    setShowModal(false);
  };

  const deleteHabit = (id) => {
    if (confirm('Delete this habit?')) {
      setHabits(habits.filter(h => h.id !== id));
    }
  };

  const incrementStreak = (id) => {
    setHabits(habits.map(h => h.id === id ? { ...h, streak: h.streak + 1 } : h));
  };

  const toggleComplete = (id) => {
    setHabits(habits.map(h => h.id === id ? { ...h, completed: !h.completed } : h));
  };

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 style={{ fontWeight: '700', marginBottom: '0.5rem' }}>Habits Tracker</h2>
          <p style={{ color: 'var(--text-secondary)' }}>Build and maintain your daily habits</p>
        </div>
        <button className="btn-primary-custom btn-custom" onClick={() => openModal()}>
          <i className="fas fa-plus me-2"></i>
          Add Habit
        </button>
      </div>

      <div className="row g-4">
        {habits.map(habit => (
          <div className="col-md-6 col-lg-4" key={habit.id}>
            <div className="stat-card">
              <div className="d-flex justify-content-between align-items-start mb-3">
                <div>
                  <h5 style={{ fontWeight: '700', marginBottom: '0.5rem' }}>{habit.name}</h5>
                  <span className="badge-custom badge-primary">{habit.frequency}</span>
                </div>
                <div className="d-flex gap-2">
                  <button className="btn-secondary-custom btn-custom btn-sm" onClick={() => openModal(habit)}>
                    <i className="fas fa-edit"></i>
                  </button>
                  <button className="btn-danger-custom btn-custom btn-sm" onClick={() => deleteHabit(habit.id)}>
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
              </div>

              {habit.description && (
                <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '1rem' }}>
                  {habit.description}
                </p>
              )}

              <div className="streak-display mb-3" style={{ width: '100%', justifyContent: 'center' }}>
                <i className="fas fa-fire"></i>
                <span>{habit.streak} Day Streak</span>
              </div>

              <div className="d-flex gap-2 mb-3">
                <button 
                  className="btn-success-custom btn-custom btn-sm flex-grow-1"
                  onClick={() => incrementStreak(habit.id)}
                >
                  <i className="fas fa-plus me-2"></i>
                  Log Today
                </button>
              </div>

              <div className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input checkbox-custom"
                  id={`habit-${habit.id}`}
                  checked={habit.completed}
                  onChange={() => toggleComplete(habit.id)}
                />
                <label className="form-check-label" htmlFor={`habit-${habit.id}`}>
                  Mark as Completed
                </label>
              </div>
            </div>
          </div>
        ))}
      </div>

      {habits.length === 0 && (
        <div className="text-center py-5">
          <i className="fas fa-check-circle" style={{ fontSize: '4rem', color: 'var(--primary-color)', opacity: 0.3 }}></i>
          <p style={{ marginTop: '1rem', color: 'var(--text-secondary)' }}>No habits tracked yet. Start building your routine!</p>
        </div>
      )}

      {showModal && (
        <div className="modal-custom" onClick={() => setShowModal(false)}>
          <div className="modal-content-custom" onClick={(e) => e.stopPropagation()}>
            <h3 className="mb-4" style={{ fontWeight: '700' }}>
              {editingHabit ? 'Edit Habit' : 'Add New Habit'}
            </h3>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Habit Name</label>
                <input
                  type="text"
                  className="form-control-custom"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                  placeholder="e.g., Morning Exercise"
                />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Frequency</label>
                <select
                  className="form-control-custom"
                  value={formData.frequency}
                  onChange={(e) => setFormData({...formData, frequency: e.target.value})}
                >
                  <option>Daily</option>
                  <option>Weekly</option>
                  <option>Monthly</option>
                </select>
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Current Streak (days)</label>
                <input
                  type="number"
                  className="form-control-custom"
                  value={formData.streak}
                  onChange={(e) => setFormData({...formData, streak: parseInt(e.target.value) || 0})}
                  min="0"
                />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Description</label>
                <textarea
                  className="form-control-custom"
                  rows="3"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Add details about this habit"
                ></textarea>
              </div>
              <div className="d-flex gap-2">
                <button type="submit" className="btn-primary-custom btn-custom flex-grow-1">
                  <i className="fas fa-save me-2"></i>
                  {editingHabit ? 'Update' : 'Add'} Habit
                </button>
                <button type="button" className="btn-secondary-custom btn-custom" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// ============= TASKS VIEW =============
function TasksView({ tasks, setTasks }) {
  const [showModal, setShowModal] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priority: 'Medium',
    dueDate: ''
  });

  const openModal = (task = null) => {
    if (task) {
      setEditingTask(task);
      setFormData({ ...task });
    } else {
      setEditingTask(null);
      setFormData({ title: '', description: '', priority: 'Medium', dueDate: '' });
    }
    setShowModal(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingTask) {
      setTasks(tasks.map(t => t.id === editingTask.id ? { ...t, ...formData } : t));
    } else {
      setTasks([...tasks, { id: Date.now(), ...formData, completed: false }]);
    }
    setShowModal(false);
  };

  const deleteTask = (id) => {
    if (confirm('Delete this task?')) {
      setTasks(tasks.filter(t => t.id !== id));
    }
  };

  const toggleComplete = (id) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'High': return 'danger';
      case 'Medium': return 'warning';
      case 'Low': return 'success';
      default: return 'primary';
    }
  };

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 style={{ fontWeight: '700', marginBottom: '0.5rem' }}>Daily Tasks</h2>
          <p style={{ color: 'var(--text-secondary)' }}>Organize and track your daily to-do items</p>
        </div>
        <button className="btn-primary-custom btn-custom" onClick={() => openModal()}>
          <i className="fas fa-plus me-2"></i>
          Add Task
        </button>
      </div>

      <div className="row g-4">
        <div className="col-12">
          <div className="stat-card">
            {tasks.map(task => (
              <div 
                key={task.id} 
                className="mb-3 p-3" 
                style={{ 
                  background: 'var(--light-bg)', 
                  borderRadius: '12px',
                  borderLeft: `4px solid var(--${getPriorityColor(task.priority)}-color)`,
                  opacity: task.completed ? 0.6 : 1
                }}
              >
                <div className="d-flex justify-content-between align-items-start">
                  <div className="d-flex align-items-start gap-3 flex-grow-1">
                    <input
                      type="checkbox"
                      className="checkbox-custom mt-1"
                      checked={task.completed}
                      onChange={() => toggleComplete(task.id)}
                    />
                    <div className="flex-grow-1">
                      <h5 style={{ 
                        fontWeight: '600', 
                        marginBottom: '0.5rem',
                        textDecoration: task.completed ? 'line-through' : 'none'
                      }}>
                        {task.title}
                      </h5>
                      {task.description && (
                        <p style={{ 
                          fontSize: '0.9rem', 
                          color: 'var(--text-secondary)', 
                          marginBottom: '0.5rem',
                          textDecoration: task.completed ? 'line-through' : 'none'
                        }}>
                          {task.description}
                        </p>
                      )}
                      <div className="d-flex gap-2 align-items-center">
                        <span className={`badge-custom badge-${getPriorityColor(task.priority)}`}>
                          {task.priority} Priority
                        </span>
                        {task.dueDate && (
                          <span className="badge-custom badge-primary">
                            <i className="fas fa-calendar me-2"></i>
                            {task.dueDate}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="d-flex gap-2">
                    <button className="btn-secondary-custom btn-custom btn-sm" onClick={() => openModal(task)}>
                      <i className="fas fa-edit"></i>
                    </button>
                    <button className="btn-danger-custom btn-custom btn-sm" onClick={() => deleteTask(task.id)}>
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {tasks.length === 0 && (
              <div className="text-center py-5">
                <i className="fas fa-tasks" style={{ fontSize: '4rem', color: 'var(--primary-color)', opacity: 0.3 }}></i>
                <p style={{ marginTop: '1rem', color: 'var(--text-secondary)' }}>No tasks yet. Add your first task to get organized!</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {showModal && (
        <div className="modal-custom" onClick={() => setShowModal(false)}>
          <div className="modal-content-custom" onClick={(e) => e.stopPropagation()}>
            <h3 className="mb-4" style={{ fontWeight: '700' }}>
              {editingTask ? 'Edit Task' : 'Add New Task'}
            </h3>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Task Title</label>
                <input
                  type="text"
                  className="form-control-custom"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  required
                  placeholder="e.g., Complete assignment"
                />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Description</label>
                <textarea
                  className="form-control-custom"
                  rows="3"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Add task details"
                ></textarea>
              </div>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label" style={{ fontWeight: '600' }}>Priority</label>
                  <select
                    className="form-control-custom"
                    value={formData.priority}
                    onChange={(e) => setFormData({...formData, priority: e.target.value})}
                  >
                    <option>High</option>
                    <option>Medium</option>
                    <option>Low</option>
                  </select>
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label" style={{ fontWeight: '600' }}>Due Date</label>
                  <input
                    type="date"
                    className="form-control-custom"
                    value={formData.dueDate}
                    onChange={(e) => setFormData({...formData, dueDate: e.target.value})}
                  />
                </div>
              </div>
              <div className="d-flex gap-2">
                <button type="submit" className="btn-primary-custom btn-custom flex-grow-1">
                  <i className="fas fa-save me-2"></i>
                  {editingTask ? 'Update' : 'Add'} Task
                </button>
                <button type="button" className="btn-secondary-custom btn-custom" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// ============= BOOKS VIEW =============
function BooksView({ books, setBooks }) {
  const [showModal, setShowModal] = useState(false);
  const [editingBook, setEditingBook] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    totalPages: 0,
    currentPage: 0,
    notes: ''
  });

  const openModal = (book = null) => {
    if (book) {
      setEditingBook(book);
      setFormData({ ...book });
    } else {
      setEditingBook(null);
      setFormData({ title: '', author: '', totalPages: 0, currentPage: 0, notes: '' });
    }
    setShowModal(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const progress = formData.totalPages > 0 ? Math.round((formData.currentPage / formData.totalPages) * 100) : 0;
    if (editingBook) {
      setBooks(books.map(b => b.id === editingBook.id ? { ...b, ...formData, progress } : b));
    } else {
      setBooks([...books, { id: Date.now(), ...formData, progress, completed: false }]);
    }
    setShowModal(false);
  };

  const deleteBook = (id) => {
    if (confirm('Delete this book?')) {
      setBooks(books.filter(b => b.id !== id));
    }
  };

  const toggleComplete = (id) => {
    setBooks(books.map(b => b.id === id ? { ...b, completed: !b.completed, currentPage: b.completed ? b.currentPage : b.totalPages } : b));
  };

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 style={{ fontWeight: '700', marginBottom: '0.5rem' }}>Books</h2>
          <p style={{ color: 'var(--text-secondary)' }}>Track your reading progress</p>
        </div>
        <button className="btn-primary-custom btn-custom" onClick={() => openModal()}>
          <i className="fas fa-plus me-2"></i>
          Add Book
        </button>
      </div>

      <div className="row g-4">
        {books.map(book => (
          <div className="col-md-6 col-lg-4" key={book.id}>
            <div className="stat-card">
              <div className="d-flex justify-content-between align-items-start mb-3">
                <div>
                  <h5 style={{ fontWeight: '700', marginBottom: '0.25rem' }}>{book.title}</h5>
                  <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: 0 }}>
                    by {book.author}
                  </p>
                </div>
                <div className="d-flex gap-2">
                  <button className="btn-secondary-custom btn-custom btn-sm" onClick={() => openModal(book)}>
                    <i className="fas fa-edit"></i>
                  </button>
                  <button className="btn-danger-custom btn-custom btn-sm" onClick={() => deleteBook(book.id)}>
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
              </div>

              <div className="mb-3">
                <div className="d-flex justify-content-between mb-2">
                  <span style={{ fontSize: '0.9rem' }}>Progress</span>
                  <span style={{ fontSize: '0.9rem', fontWeight: '600', color: 'var(--primary-color)' }}>
                    {book.currentPage} / {book.totalPages} pages
                  </span>
                </div>
                <div className="progress-custom">
                  <div className="progress-bar-custom" style={{ width: `${book.progress}%` }}></div>
                </div>
              </div>

              {book.notes && (
                <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '1rem' }}>
                  {book.notes}
                </p>
              )}

              <div className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input checkbox-custom"
                  id={`book-${book.id}`}
                  checked={book.completed}
                  onChange={() => toggleComplete(book.id)}
                />
                <label className="form-check-label" htmlFor={`book-${book.id}`}>
                  Mark as Finished
                </label>
              </div>
            </div>
          </div>
        ))}
      </div>

      {books.length === 0 && (
        <div className="text-center py-5">
          <i className="fas fa-book" style={{ fontSize: '4rem', color: 'var(--primary-color)', opacity: 0.3 }}></i>
          <p style={{ marginTop: '1rem', color: 'var(--text-secondary)' }}>No books added yet. Start your reading journey!</p>
        </div>
      )}

      {showModal && (
        <div className="modal-custom" onClick={() => setShowModal(false)}>
          <div className="modal-content-custom" onClick={(e) => e.stopPropagation()}>
            <h3 className="mb-4" style={{ fontWeight: '700' }}>
              {editingBook ? 'Edit Book' : 'Add New Book'}
            </h3>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Book Title</label>
                <input
                  type="text"
                  className="form-control-custom"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  required
                  placeholder="e.g., Atomic Habits"
                />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Author</label>
                <input
                  type="text"
                  className="form-control-custom"
                  value={formData.author}
                  onChange={(e) => setFormData({...formData, author: e.target.value})}
                  required
                  placeholder="e.g., James Clear"
                />
              </div>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label" style={{ fontWeight: '600' }}>Total Pages</label>
                  <input
                    type="number"
                    className="form-control-custom"
                    value={formData.totalPages}
                    onChange={(e) => setFormData({...formData, totalPages: parseInt(e.target.value) || 0})}
                    required
                    min="1"
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label" style={{ fontWeight: '600' }}>Current Page</label>
                  <input
                    type="number"
                    className="form-control-custom"
                    value={formData.currentPage}
                    onChange={(e) => setFormData({...formData, currentPage: Math.min(formData.totalPages, parseInt(e.target.value) || 0)})}
                    min="0"
                  />
                </div>
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Notes</label>
                <textarea
                  className="form-control-custom"
                  rows="3"
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  placeholder="Add your thoughts or notes"
                ></textarea>
              </div>
              <div className="d-flex gap-2">
                <button type="submit" className="btn-primary-custom btn-custom flex-grow-1">
                  <i className="fas fa-save me-2"></i>
                  {editingBook ? 'Update' : 'Add'} Book
                </button>
                <button type="button" className="btn-secondary-custom btn-custom" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// ============= MOVIES VIEW =============
function MoviesView({ movies, setMovies }) {
  const [showModal, setShowModal] = useState(false);
  const [editingMovie, setEditingMovie] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    genre: '',
    rating: 0,
    review: ''
  });

  const openModal = (movie = null) => {
    if (movie) {
      setEditingMovie(movie);
      setFormData({ ...movie });
    } else {
      setEditingMovie(null);
      setFormData({ title: '', genre: '', rating: 0, review: '' });
    }
    setShowModal(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingMovie) {
      setMovies(movies.map(m => m.id === editingMovie.id ? { ...m, ...formData } : m));
    } else {
      setMovies([...movies, { id: Date.now(), ...formData, completed: false }]);
    }
    setShowModal(false);
  };

  const deleteMovie = (id) => {
    if (confirm('Delete this movie?')) {
      setMovies(movies.filter(m => m.id !== id));
    }
  };

  const toggleComplete = (id) => {
    setMovies(movies.map(m => m.id === id ? { ...m, completed: !m.completed } : m));
  };

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 style={{ fontWeight: '700', marginBottom: '0.5rem' }}>Movies</h2>
          <p style={{ color: 'var(--text-secondary)' }}>Track movies you want to watch or have watched</p>
        </div>
        <button className="btn-primary-custom btn-custom" onClick={() => openModal()}>
          <i className="fas fa-plus me-2"></i>
          Add Movie
        </button>
      </div>

      <div className="row g-4">
        {movies.map(movie => (
          <div className="col-md-6 col-lg-4" key={movie.id}>
            <div className="stat-card">
              <div className="d-flex justify-content-between align-items-start mb-3">
                <div>
                  <h5 style={{ fontWeight: '700', marginBottom: '0.25rem' }}>{movie.title}</h5>
                  <span className="badge-custom badge-secondary">{movie.genre}</span>
                </div>
                <div className="d-flex gap-2">
                  <button className="btn-secondary-custom btn-custom btn-sm" onClick={() => openModal(movie)}>
                    <i className="fas fa-edit"></i>
                  </button>
                  <button className="btn-danger-custom btn-custom btn-sm" onClick={() => deleteMovie(movie.id)}>
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
              </div>

              {movie.rating > 0 && (
                <div className="mb-3">
                  <div style={{ color: 'var(--warning-color)', fontSize: '1.2rem' }}>
                    {'★'.repeat(movie.rating)}{'☆'.repeat(5 - movie.rating)}
                  </div>
                </div>
              )}

              {movie.review && (
                <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '1rem' }}>
                  {movie.review}
                </p>
              )}

              <div className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input checkbox-custom"
                  id={`movie-${movie.id}`}
                  checked={movie.completed}
                  onChange={() => toggleComplete(movie.id)}
                />
                <label className="form-check-label" htmlFor={`movie-${movie.id}`}>
                  {movie.completed ? 'Watched' : 'Mark as Watched'}
                </label>
              </div>
            </div>
          </div>
        ))}
      </div>

      {movies.length === 0 && (
        <div className="text-center py-5">
          <i className="fas fa-film" style={{ fontSize: '4rem', color: 'var(--primary-color)', opacity: 0.3 }}></i>
          <p style={{ marginTop: '1rem', color: 'var(--text-secondary)' }}>No movies added yet. Start your watchlist!</p>
        </div>
      )}

      {showModal && (
        <div className="modal-custom" onClick={() => setShowModal(false)}>
          <div className="modal-content-custom" onClick={(e) => e.stopPropagation()}>
            <h3 className="mb-4" style={{ fontWeight: '700' }}>
              {editingMovie ? 'Edit Movie' : 'Add New Movie'}
            </h3>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Movie Title</label>
                <input
                  type="text"
                  className="form-control-custom"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  required
                  placeholder="e.g., The Shawshank Redemption"
                />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Genre</label>
                <input
                  type="text"
                  className="form-control-custom"
                  value={formData.genre}
                  onChange={(e) => setFormData({...formData, genre: e.target.value})}
                  placeholder="e.g., Drama, Action, Comedy"
                />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Rating (0-5 stars)</label>
                <input
                  type="number"
                  className="form-control-custom"
                  value={formData.rating}
                  onChange={(e) => setFormData({...formData, rating: Math.min(5, Math.max(0, parseInt(e.target.value) || 0))})}
                  min="0"
                  max="5"
                />
              </div>
              <div className="mb-3">
                <label className="form-label" style={{ fontWeight: '600' }}>Review</label>
                <textarea
                  className="form-control-custom"
                  rows="3"
                  value={formData.review}
                  onChange={(e) => setFormData({...formData, review: e.target.value})}
                  placeholder="Share your thoughts"
                ></textarea>
              </div>
              <div className="d-flex gap-2">
                <button type="submit" className="btn-primary-custom btn-custom flex-grow-1">
                  <i className="fas fa-save me-2"></i>
                  {editingMovie ? 'Update' : 'Add'} Movie
                </button>
                <button type="button" className="btn-secondary-custom btn-custom" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// ============= CALENDAR VIEW =============
function CalendarView({ exams, tasks }) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);

  const getDaysInMonth = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    return { firstDay, daysInMonth };
  };

  const { firstDay, daysInMonth } = getDaysInMonth(currentDate);
  const monthName = currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });

  const getEventsForDate = (day) => {
    const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const examEvents = exams.filter(e => e.date === dateStr);
    const taskEvents = tasks.filter(t => t.dueDate === dateStr);
    return [...examEvents, ...taskEvents];
  };

  const changeMonth = (direction) => {
    const newDate = new Date(currentDate);
    newDate.setMonth(newDate.getMonth() + direction);
    setCurrentDate(newDate);
  };

  return (
    <div>
      <div className="mb-4">
        <h2 style={{ fontWeight: '700', marginBottom: '0.5rem' }}>Calendar</h2>
        <p style={{ color: 'var(--text-secondary)' }}>View your exams and tasks in calendar format</p>
      </div>

      <div className="stat-card">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <button className="btn-secondary-custom btn-custom" onClick={() => changeMonth(-1)}>
            <i className="fas fa-chevron-left"></i>
          </button>
          <h3 style={{ fontWeight: '700', margin: 0 }}>{monthName}</h3>
          <button className="btn-secondary-custom btn-custom" onClick={() => changeMonth(1)}>
            <i className="fas fa-chevron-right"></i>
          </button>
        </div>

        <div className="calendar-grid mb-4">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} style={{ textAlign: 'center', fontWeight: '600', padding: '0.5rem' }}>
              {day}
            </div>
          ))}
          {[...Array(firstDay)].map((_, i) => (
            <div key={`empty-${i}`}></div>
          ))}
          {[...Array(daysInMonth)].map((_, i) => {
            const day = i + 1;
            const events = getEventsForDate(day);
            const hasEvents = events.length > 0;
            return (
              <div
                key={day}
                className={`calendar-day ${hasEvents ? 'has-event' : ''}`}
                onClick={() => setSelectedDate(day)}
              >
                <div style={{ fontWeight: '600' }}>{day}</div>
                {hasEvents && (
                  <div style={{ fontSize: '0.7rem', marginTop: '0.25rem' }}>
                    {events.length} event{events.length > 1 ? 's' : ''}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {selectedDate && (
          <div className="p-3" style={{ background: 'var(--light-bg)', borderRadius: '12px' }}>
            <h5 style={{ fontWeight: '700', marginBottom: '1rem' }}>
              Events on {monthName} {selectedDate}
            </h5>
            {getEventsForDate(selectedDate).map((event, index) => (
              <div key={index} className="mb-2 p-2" style={{ background: 'var(--light-card)', borderRadius: '8px' }}>
                <div className="d-flex align-items-center gap-2">
                  <i className={`fas fa-${event.totalTopics !== undefined ? 'book-open' : 'tasks'}`} style={{ color: 'var(--primary-color)' }}></i>
                  <div>
                    <div style={{ fontWeight: '600' }}>{event.name || event.title}</div>
                    <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                      {event.totalTopics !== undefined ? 'Exam' : `Task - ${event.priority} Priority`}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            {getEventsForDate(selectedDate).length === 0 && (
              <p style={{ color: 'var(--text-secondary)', marginBottom: 0 }}>No events scheduled</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ============= KANBAN VIEW =============
function KanbanView({ tasks, setTasks, subjects, setSubjects }) {
  const columns = [
    { id: 'todo', title: 'To Do', color: 'var(--danger-color)' },
    { id: 'inprogress', title: 'In Progress', color: 'var(--warning-color)' },
    { id: 'done', title: 'Done', color: 'var(--success-color)' }
  ];

  const [kanbanTasks, setKanbanTasks] = useState(tasks.map(t => ({ ...t, column: t.completed ? 'done' : 'todo' })));
  const [kanbanSubjects, setKanbanSubjects] = useState(subjects.map(s => ({ ...s, column: s.completed ? 'done' : s.progress > 50 ? 'inprogress' : 'todo' })));

  const moveCard = (id, newColumn, isSubject = false) => {
    if (isSubject) {
      setKanbanSubjects(kanbanSubjects.map(s => s.id === id ? { ...s, column: newColumn } : s));
      setSubjects(subjects.map(s => s.id === id ? { ...s, completed: newColumn === 'done' } : s));
    } else {
      setKanbanTasks(kanbanTasks.map(t => t.id === id ? { ...t, column: newColumn } : t));
      setTasks(tasks.map(t => t.id === id ? { ...t, completed: newColumn === 'done' } : t));
    }
  };

  return (
    <div>
      <div className="mb-4">
        <h2 style={{ fontWeight: '700', marginBottom: '0.5rem' }}>Kanban Board</h2>
        <p style={{ color: 'var(--text-secondary)' }}>Visual board for tasks and subjects</p>
      </div>

      <div className="kanban-board">
        {columns.map(column => (
          <div key={column.id} className="kanban-column">
            <h4 style={{ fontWeight: '700', marginBottom: '1.5rem', borderLeft: `4px solid ${column.color}`, paddingLeft: '1rem' }}>
              {column.title}
            </h4>
            <div>
              {kanbanTasks.filter(t => t.column === column.id).map(task => (
                <div key={`task-${task.id}`} className="kanban-card">
                  <div className="d-flex justify-content-between align-items-start mb-2">
                    <h6 style={{ fontWeight: '600' }}>{task.title}</h6>
                    <span className="badge-custom badge-primary">Task</span>
                  </div>
                  {task.description && (
                    <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>
                      {task.description}
                    </p>
                  )}
                  <div className="d-flex gap-1">
                    {columns.map(col => col.id !== column.id && (
                      <button
                        key={col.id}
                        className="btn-secondary-custom btn-custom btn-sm"
                        onClick={() => moveCard(task.id, col.id, false)}
                        style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem' }}
                      >
                        → {col.title}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              {kanbanSubjects.filter(s => s.column === column.id).map(subject => (
                <div key={`subject-${subject.id}`} className="kanban-card" style={{ borderLeftColor: 'var(--secondary-color)' }}>
                  <div className="d-flex justify-content-between align-items-start mb-2">
                    <h6 style={{ fontWeight: '600' }}>{subject.name}</h6>
                    <span className="badge-custom badge-secondary">Subject</span>
                  </div>
                  <div className="progress-custom mb-2">
                    <div className="progress-bar-custom" style={{ width: `${subject.progress}%` }}></div>
                  </div>
                  <div className="d-flex gap-1">
                    {columns.map(col => col.id !== column.id && (
                      <button
                        key={col.id}
                        className="btn-secondary-custom btn-custom btn-sm"
                        onClick={() => moveCard(subject.id, col.id, true)}
                        style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem' }}
                      >
                        → {col.title}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============= ADMIN PANEL =============
function AdminPanel({ users, setUsers, exams, setExams, habits, setHabits, tasks, setTasks, books, setBooks, movies, setMovies, subjects, setSubjects }) {
  const [activeTab, setActiveTab] = useState('users');

  const deleteUser = (id) => {
    if (confirm('Delete this user? This action cannot be undone.')) {
      setUsers(users.filter(u => u.id !== id));
    }
  };

  const stats = [
    { label: 'Total Users', value: users.length, icon: 'users', color: 'primary' },
    { label: 'Total Exams', value: exams.length, icon: 'book-open', color: 'success' },
    { label: 'Total Tasks', value: tasks.length, icon: 'tasks', color: 'warning' },
    { label: 'Total Habits', value: habits.length, icon: 'check-circle', color: 'danger' },
  ];

  return (
    <div>
      <div className="mb-4">
        <h2 style={{ fontWeight: '700', marginBottom: '0.5rem' }}>
          <i className="fas fa-user-shield me-2" style={{ color: 'var(--primary-color)' }}></i>
          Admin Panel
        </h2>
        <p style={{ color: 'var(--text-secondary)' }}>Manage all users and data</p>
      </div>

      <div className="row g-4 mb-4">
        {stats.map((stat, index) => (
          <div className="col-md-6 col-lg-3" key={index}>
            <div className="stat-card">
              <div className={`stat-card-icon icon-${stat.color}`}>
                <i className={`fas fa-${stat.icon}`}></i>
              </div>
              <h3 style={{ fontSize: '2rem', fontWeight: '700', marginBottom: '0.25rem' }}>{stat.value}</h3>
              <p style={{ color: 'var(--text-secondary)', marginBottom: 0 }}>{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="stat-card">
        <div className="d-flex gap-2 mb-4" style={{ borderBottom: '2px solid rgba(0, 0, 0, 0.1)', paddingBottom: '1rem' }}>
          {['users', 'exams', 'habits', 'tasks', 'books', 'movies', 'subjects'].map(tab => (
            <button
              key={tab}
              className={`btn-custom ${activeTab === tab ? 'btn-primary-custom' : 'btn-secondary-custom'}`}
              onClick={() => setActiveTab(tab)}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {activeTab === 'users' && (
          <div className="table-responsive">
            <table className="table-custom">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.id}>
                    <td>{user.id}</td>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td>
                      <span className={`badge-custom badge-${user.isAdmin ? 'danger' : 'primary'}`}>
                        {user.isAdmin ? 'Admin' : 'User'}
                      </span>
                    </td>
                    <td>
                      <button className="btn-danger-custom btn-custom btn-sm" onClick={() => deleteUser(user.id)}>
                        <i className="fas fa-trash"></i> Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'exams' && (
          <AdminDataTable 
            data={exams} 
            setData={setExams} 
            columns={['id', 'name', 'date', 'progress']}
            title="Exams"
          />
        )}

        {activeTab === 'habits' && (
          <AdminDataTable 
            data={habits} 
            setData={setHabits} 
            columns={['id', 'name', 'frequency', 'streak']}
            title="Habits"
          />
        )}

        {activeTab === 'tasks' && (
          <AdminDataTable 
            data={tasks} 
            setData={setTasks} 
            columns={['id', 'title', 'priority', 'dueDate']}
            title="Tasks"
          />
        )}

        {activeTab === 'books' && (
          <AdminDataTable 
            data={books} 
            setData={setBooks} 
            columns={['id', 'title', 'author', 'progress']}
            title="Books"
          />
        )}

        {activeTab === 'movies' && (
          <AdminDataTable 
            data={movies} 
            setData={setMovies} 
            columns={['id', 'title', 'genre', 'rating']}
            title="Movies"
          />
        )}

        {activeTab === 'subjects' && (
          <AdminDataTable 
            data={subjects} 
            setData={setSubjects} 
            columns={['id', 'examId', 'name', 'progress']}
            title="Subjects"
          />
        )}
      </div>
    </div>
  );
}

function AdminDataTable({ data, setData, columns, title }) {
  const deleteItem = (id) => {
    if (confirm(`Delete this ${title.toLowerCase()} item?`)) {
      setData(data.filter(item => item.id !== id));
    }
  };

  return (
    <div className="table-responsive">
      <table className="table-custom">
        <thead>
          <tr>
            {columns.map(col => (
              <th key={col}>{col.charAt(0).toUpperCase() + col.slice(1)}</th>
            ))}
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => (
            <tr key={item.id}>
              {columns.map(col => (
                <td key={col}>{String(item[col] || '-')}</td>
              ))}
              <td>
                <button className="btn-danger-custom btn-custom btn-sm" onClick={() => deleteItem(item.id)}>
                  <i className="fas fa-trash"></i> Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {data.length === 0 && (
        <div className="text-center py-4" style={{ color: 'var(--text-secondary)' }}>
          No {title.toLowerCase()} data available
        </div>
      )}
    </div>
  );
}

// ============= FOOTER =============
function Footer() {
  return (
    <footer className="footer">
      <p style={{ margin: 0, fontSize: '1.1rem', fontWeight: '600' }}>
        Made with <span className="footer-heart">❤️</span> by Bhav
      </p>
      <p style={{ margin: '0.5rem 0 0 0', fontSize: '0.9rem', opacity: 0.9 }}>
        © {new Date().getFullYear()} ExamPrep Pro - Your Ultimate Study Companion
      </p>
    </footer>
  );
}

// ============= UTILITY FUNCTIONS =============
function calculateDaysRemaining(dateStr) {
  if (!dateStr) return 0;
  const examDate = new Date(dateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diffTime = examDate - today;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(0, diffDays);
}

// ============= RENDER APP =============
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);